<h1>Site Portifólio</h1>
<h3>⚠️ Site em construção 🛠️</h3> <br>
<p>Este repositório contém um projeto de um site voltado para mostrar meu portifólio. Estou utilizando-o como exercício de aprendizagem para HTML e CSS.</p>
